Python module to produced bootstrapped confidence intervals and effect sizes. Requires matplotlib, seaborn, numpy, scipy, and pandas (version at least 0.20.3).

To obtain these package dependencies easily, it is highly recommended to download the Anaconda distribution of Python from [https://www.continuum.io/downloads](https://www.continuum.io/downloads).

Python 3.6 is strongly recommended, although this has been tested with Python 2.7 and Python 3.5.
